package com.tammem.dimmer;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private Switch sw;
    private TextView info;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final SharedPreferences prefs = getSharedPreferences("p", MODE_PRIVATE);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("تعتيم الشاشة"); title.setTextSize(26f); title.setGravity(Gravity.CENTER);
        root.addView(title);

        info = new TextView(this);
        info.setTextSize(18f); info.setGravity(Gravity.CENTER); info.setPadding(0, pad, 0, pad);
        root.addView(info);

        sw = new Switch(this);
        sw.setText("تشغيل التعتيم"); sw.setTextSize(18f);
        root.addView(sw);

        final SeekBar seek = new SeekBar(this);
        seek.setMax(95); seek.setProgress(prefs.getInt("level", 50)); seek.setPadding(0, pad, 0, pad);
        root.addView(seek);
        setContentView(root);
        refresh(seek.getProgress());

        sw.setOnCheckedChangeListener((btn, on) -> {
            if (on) {
                if (!Settings.canDrawOverlays(this)) {
                    sw.setChecked(false);
                    Toast.makeText(this, "عطي صلاحية العرض فوق التطبيقات", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                } else {
                    if (Build.VERSION.SDK_INT >= 33)
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                    startForegroundService(new Intent(this, DimService.class).putExtra("level", seek.getProgress()));
                }
            } else stopService(new Intent(this, DimService.class));
        });

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                prefs.edit().putInt("level", p).apply();
                refresh(p);
                if (DimService.running)
                    startForegroundService(new Intent(MainActivity.this, DimService.class).putExtra("level", p));
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
    }

    @Override protected void onResume() { super.onResume(); sw.setChecked(DimService.running); }

    private void refresh(int p) { info.setText("درجة الظلمة: " + p + "%"); }
}
