package com.tammem.dimmer;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.View;
import android.view.WindowManager;

public class DimService extends Service {
    public static boolean running = false;
    private View overlay;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        startFg();
        int saved = getSharedPreferences("p", MODE_PRIVATE).getInt("level", 50);
        int level = intent != null ? intent.getIntExtra("level", saved) : saved;
        show(level);
        running = true;
        return START_STICKY;
    }

    private void startFg() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("dim", "تعتيم الشاشة", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, DimService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "dim")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("التعتيم شغّال")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "إيقاف", stop).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    private void show(int level) {
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int a = Math.max(0, Math.min(95, level)) * 255 / 100;
        if (overlay == null) {
            View v = new View(this);
            int w, h;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Rect r = wm.getMaximumWindowMetrics().getBounds();
                w = r.width(); h = r.height();
            } else {
                android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
                wm.getDefaultDisplay().getRealMetrics(dm);
                w = dm.widthPixels; h = dm.heightPixels;
            }
            int extra = 400; // يغطي الشريط العلوي والسفلي والنوتش
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    w + extra, h + extra,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
            lp.x = -extra / 2;
            lp.y = -extra / 2;
            if (Build.VERSION.SDK_INT >= 30)
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            else if (Build.VERSION.SDK_INT >= 28)
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            v.setBackgroundColor(Color.argb(a, 0, 0, 0));
            wm.addView(v, lp);
            overlay = v;
        } else overlay.setBackgroundColor(Color.argb(a, 0, 0, 0));
    }

    @Override public void onDestroy() {
        if (overlay != null) {
            ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).removeView(overlay);
            overlay = null;
        }
        running = false;
        super.onDestroy();
    }
}
